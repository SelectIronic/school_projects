require 'minitest/autorun'
require_relative 'PuzzleClass.rb'

class TestPuzzleClass < Minitest::Test
  def setup
    @p = PuzzleClass.new(4, 4)
    @p.set_puzzle("1234\n5 67\n89ab\ncdef")
    @p.solve
  end

  def test_get_puzzle
    @p.set_puzzle("1234\n5 67\n89ab\ncdef")
    @p.solve
    assert_equal("1234\n5 67\n89ab\ncdef", @p.get_puzzle)
  end

  def test_move_up
    @p.set_puzzle("1234\n5 67\n89ab\ncdef")
    @p.solve
    @p.move_up
    assert_equal("1 34\n5267\n89ab\ncdef", @p.get_puzzle)
    @p.move_up
    assert_equal("1 34\n5267\n89ab\ncdef", @p.get_puzzle)
  end

  def test_move_down
    @p.set_puzzle("1234\n5 67\n89ab\ncdef")
    @p.solve
    @p.move_down
    assert_equal("1234\n5967\n8 ab\ncdef", @p.get_puzzle)
    @p.move_down
    assert_equal("1234\n5967\n8dab\nc ef", @p.get_puzzle)
    @p.move_down
    assert_equal("1234\n5967\n8dab\nc ef", @p.get_puzzle)
  end

  def test_move_right
    @p.set_puzzle("1234\n5 67\n89ab\ncdef")
    @p.solve
    @p.move_right
    assert_equal("1234\n56 7\n89ab\ncdef", @p.get_puzzle)
    @p.move_right
    assert_equal("1234\n567 \n89ab\ncdef", @p.get_puzzle)
    @p.move_right
    assert_equal("1234\n567 \n89ab\ncdef", @p.get_puzzle)
  end

  def test_move_left
    @p.set_puzzle("1234\n5 67\n89ab\ncdef")
    @p.solve
    @p.move_left
    assert_equal("1234\n 567\n89ab\ncdef", @p.get_puzzle)
    @p.move_left
    assert_equal("1234\n 567\n89ab\ncdef", @p.get_puzzle)
  end

  def test_solve
    @p.scramble
    @p.solve
    assert_equal("1234\n5 67\n89ab\ncdef", @p.get_puzzle)
  end

  def test_scramble
    @p.set_puzzle("1234\n5 67\n89ab\ncdef")
    @p.solve
    @p.scramble
    refute_equal("1234\n5 67\n89ab\ncdef", @p.get_puzzle)
  end

  def test_to_s
    @p.set_puzzle("1234\n5 67\n89ab\ncdef")
    @p.solve
    assert_equal("12345 6789abcdef", @p.to_s)
  end

  # def test_run_puzzle
  #   @p.run_puzzle
  # end

end