class PuzzleClass
  attr_accessor :width, :height, :puzzle
  attr_reader :solution, :solved_space_coords, :space_coords

  def initialize(width = 2, height = 2)
    @width = width.to_i
    @height = height.to_i
    @puzzle = Array.new(@height) { Array.new(@width) }
    @solution = Array.new(@height) { Array.new(@width) }
    @solved_space_coords = [@width - 1, @height - 1]
    @space_coords = [@width - 1, @height - 1]
  end

  def set_puzzle(puzzle_string)
    new_rows = []
    data_invalid = false
    space_found = false
    temp_space_coords = []

    if puzzle_string.class == String
      new_rows = puzzle_string.split("\n")
      current_row = 0
      new_rows.each { |row_string|
        new_row = row_string.split('')
        new_rows[current_row] = new_row
        current_cell = 0
        new_row.each { |new_cell|
          if new_cell == ' '
            if space_found
              data_invalid = true
            else
              space_found = true
              temp_space_coords[0] = current_cell
              temp_space_coords[1] = current_row
            end
          end
          current_cell += 1
        }
        current_row += 1
      }
    else
      data_invalid = true
    end

    if data_invalid
      "DATA INVALID: please pass in a 2D array of dimensions #{@width} x #{@height} including one element: ' ' (space)"
    else
      @solution = new_rows
      @solved_space_coords = temp_space_coords
    end

  end

  def get_puzzle
    ret_str = ''
    @puzzle.each { |row|
      ret_str += row.join('')
      ret_str += "\n"
    }
    ret_str.chomp!
    ret_str
  end

  def move_up
    if space_coords[1] > 0
      # @puzzle[space_coords[1]][space_coords[0]], @puzzle[(space_coords[1] - 1)][space_coords[0]] = [(space_coords[1] - 1)][space_coords[0]], @puzzle[space_coords[1]][space_coords[0]]
      moving_tile = @puzzle[(space_coords[1] - 1)][space_coords[0]]
      @puzzle[(space_coords[1] - 1)][space_coords[0]] = ' '
      @puzzle[space_coords[1]][space_coords[0]] = moving_tile
      space_coords[1] -= 1
    end
  end

  def move_down
    if space_coords[1] < (@height - 1)
      # @puzzle[space_coords[1]][space_coords[0]], @puzzle[(space_coords[1] + 1)][space_coords[0]] = [(space_coords[1] + 1)][space_coords[0]], @puzzle[space_coords[1]][space_coords[0]]
      moving_tile = @puzzle[(space_coords[1] + 1)][space_coords[0]]
      @puzzle[(space_coords[1] + 1)][space_coords[0]] = ' '
      @puzzle[space_coords[1]][space_coords[0]] = moving_tile
      space_coords[1] += 1
    end
  end

  def move_right
    if space_coords[0] < (@width - 1)
      # @puzzle[space_coords[1]][space_coords[0]], @puzzle[space_coords[1]][(space_coords[0] + 1)] = [space_coords[1]][(space_coords[0] + 1)], @puzzle[space_coords[1]][space_coords[0]]
      moving_tile = @puzzle[space_coords[1]][(space_coords[0] + 1)]
      @puzzle[space_coords[1]][(space_coords[0] + 1)] = ' '
      @puzzle[space_coords[1]][space_coords[0]] = moving_tile
      space_coords[0] += 1
    end
  end

  def move_left
    if space_coords[0] > 0
      # @puzzle[space_coords[1]][space_coords[0]], @puzzle[space_coords[1]][(space_coords[0] - 1)] = [space_coords[1]][(space_coords[0] - 1)], @puzzle[space_coords[1]][space_coords[0]]
      moving_tile = @puzzle[space_coords[1]][(space_coords[0] - 1)]
      @puzzle[space_coords[1]][(space_coords[0] - 1)] = ' '
      @puzzle[space_coords[1]][space_coords[0]] = moving_tile
      space_coords[0] -= 1
    end
  end

  def solve
    # @puzzle = @solution
    row_index = 0
    @height.times {
      cell_index = 0
      @width.times {
        value_of_cell = @solution[row_index][cell_index]
        @puzzle[row_index][cell_index] = value_of_cell
        cell_index +=1
      }
      row_index += 1
    }
    a = @solved_space_coords[0]
    @space_coords[0] = a
    a = @solved_space_coords[1]
    @space_coords[1] = a
  end

  def scramble
    #old_state = @puzzle
    old_state = Array.new(@height) { Array.new(@width) }
    #TODO: extract array copying into method
    row_index = 0
    @height.times {
      cell_index = 0
      @width.times {
        value_of_cell = @puzzle[row_index][cell_index]
        old_state[row_index][cell_index] = value_of_cell
        cell_index +=1
      }
      row_index += 1
    }
    while @puzzle == old_state
      scrambler = []
      @puzzle.each { |row|
        row.each { |tile|
          scrambler.push(tile)
        }
      }
      current_row = 0
      @height.times {
        current_cell = 0
        @width.times {
          scrambler.shuffle!
          next_tile = scrambler.pop
          @puzzle[current_row][current_cell] = next_tile
          if next_tile == ' '
            @space_coords = [current_cell, current_row]
          end
          current_cell += 1
        }
        current_row += 1
      }
    end
  end

  def to_s
    ret_str = ''
    @puzzle.each { |row| ret_str += row.join('') }
    ret_str
  end

  # note: get_puzzle should be run before run_puzzle
  def run_puzzle
    self.solve
    puts self.get_puzzle
    keyboard_input = 1
    until keyboard_input == 'q'
      puts 'i, k, l, j: move up, down, right, left, respectively.'
      puts 's: solve; x: scramble; q: quit'
      keyboard_input = gets.chomp
      case keyboard_input
        when 'i'
          self.move_up
        when 'k'
          self.move_down
        when 'l'
          self.move_right
        when 'j'
          self.move_left
        when 's'
          self.solve
        when 'x'
          self.scramble
        else
          puts 'command not recognized'
      end
      puts self.get_puzzle
    end
  end

end