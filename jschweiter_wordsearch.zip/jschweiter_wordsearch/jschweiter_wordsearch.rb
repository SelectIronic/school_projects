############################################################
#
#  Name:        John Schweiter
#  Assignment:  Word Search - Main
#  Date:        5/27/2015
#  Class:       CIS 283
#  Description: Final Project word search puzzle generator.
#
############################################################

require_relative 'puzzleclass'
require 'prawn'

word_list = []
words_file = File.open('words.txt', 'r+')
until words_file.eof?
  word_list.push(words_file.gets.chomp.upcase!.delete(' '))
end
words_file.close

my_puzzle = Puzzle.new(45, 45, word_list)
my_puzzle.generate

puts my_puzzle
puts my_puzzle.words_to_find
puts my_puzzle.key
puts my_puzzle.words_to_find

Prawn::Document.generate('jschweiter_wordsearch.pdf') { |pdf|
  pdf.font 'Courier', :size => 24
  pdf.text 'Word Search', :align => :center
  pdf.font_size = 10
  pdf.text "Fruits\n\n", :align => :center
  pdf.text "#{my_puzzle}"
  pdf.text my_puzzle.words_to_find
  pdf.start_new_page
  pdf.font_size = 24
  pdf.text 'Word Search Key', :align => :center
  pdf.font_size = 10
  pdf.text "Fruits\n\n", :align => :center
  pdf.text "#{my_puzzle.key}"
  pdf.text my_puzzle.words_to_find
}

