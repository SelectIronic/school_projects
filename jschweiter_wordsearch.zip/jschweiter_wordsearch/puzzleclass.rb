############################################################
#
#  Name:        John Schweiter
#  Assignment:  Word Search Puzzle Class
#  Date:        5/27/2015
#  Class:       CIS 283
#  Description: Makes word search puzzle objects for Final Project.
#
############################################################

class Puzzle

  def initialize(height, width, word_list)
    @height = height.to_i > 0 ? height.to_i : 1
    @width = width.to_i > 0 ? width.to_i : 1
    @grid = Array.new(@height) { Array.new(@width) {'.'} }
    @word_list = word_list.sort_by! { |word| word.length }.reverse!
    @letters = []
    @word_list.each { |word|
      word.split('').each { |letter|
        unless @letters.include?(letter)
          @letters.push(letter).sort!
        end
      }
    }
  end

  def generate
    @word_list.each { |word|
      fit = false
      posy = rand(0...@height)
      posx = rand(0...@width)
      varray = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]]
      until fit
        fit = true
        if varray.empty?
          varray = [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]]
          posy = rand(0...@height)
          posx = rand(0...@width)
        end
        varray.shuffle!
        v = varray.pop
        vy = v[0]
        vx = v[1]
        i = 0
        until i == word.length || !fit
          if posy + (i * vy) < @height && posx + (i * vx) < @width && posy + (i * vy) >= 0 && posx + (i * vx) >= 0
            unless @grid[posy+(i * vy)][posx+(i * vx)] == word[i] || @grid[posy+(i * vy)][posx+(i * vx)] == '.'
              fit = false
            end
          else
            fit = false
          end
          i += 1
        end
        if fit
          i = 0
          word.length.times {
            @grid[posy+(i * vy)][posx+(i * vx)] = word[i]
            i += 1
          }
        end
      end
    }
  end

  def key
    printgrid = ''
    @grid.each { |row| printgrid += "#{row.join(' ')}\n" }
    printgrid
  end

  def words_to_find
    printwords = ''
    printwords += "\n\nWords to find:\n"
    i = 0
    (@word_list.length / 3).times {
      printwords += "#{@word_list[(0+i)].ljust(15)}#{@word_list[(1+i)].ljust(15)}#{@word_list[(2+i)]}\n"
      i += 3
    }
    printwords
  end
  def to_s
    printgrid = ''
    @grid.each { |row|
      printrow = ''
      row.each { |letter| printrow += letter == '.' ? "#{@letters[rand(0...@letters.length)]} " : "#{letter} "}
      printgrid += "#{printrow}\n"
    }
    printgrid
  end

end