package com.example.john.battleship_schweiter;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


interface ServerRequests {
    void ProcessResponse( String command, String response );
}

public class MainActivity extends BaseActivity implements ServerRequests {

    //{"game_id":6327}

    String username = "JohnS2774@bigfoot.spokane.edu";
    String password = "IT'S A TRAP!";

    Button loginButton, btnStartGame, startExistingGame;
    static Button userPreferences;
    EditText edtUsername, edtPassword, edtGameID;
//    NetworkImageView imgAvatar;
    ListView listView;

    @Override
    protected void onCreate( Bundle savedInstanceState ) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        listView = (ListView) findViewById( R.id.listView );
        loginButton = (Button) findViewById( R.id.btnLogin );
        btnStartGame = (Button) findViewById( R.id.btnStartGame );
        startExistingGame = (Button) findViewById( R.id.btnStartExisting );
        edtUsername = (EditText) findViewById( R.id.edtUsername );
        edtPassword = (EditText) findViewById( R.id.edtPassword );
        edtGameID = (EditText) findViewById( R.id.edtGameID );
        userPreferences = (Button) findViewById( R.id.btnPreferences );
        if( userPreferences != null ) {
            userPreferences.setEnabled( false );
        }
        startExistingGame.setEnabled( false );
        btnStartGame.setEnabled( false );

        // VOLLEY
        RequestQueue queue = Volley.newRequestQueue( this );
        sr = new ServerRequest( this, "LOGIN", username, password, loginUrl, queue );

        // Defined Array values to show in ListView
        String[] values = new String[] {};

        // http://androidexample.com/Create_A_Simple_Listview_-_Android_Example/index.php?view=article_discription&aid=65&aaid=90
        // Define a new Adapter
        // First parameter - Context
        // Second parameter - Layout for the row
        // Third parameter - ID of the TextView to which the data is written
        // Fourth - the Array of data
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, values);

        // Assign adapter to ListView
        listView.setAdapter(adapter);

        // ListView Item Click Listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                // ListView Clicked item index

                // ListView Clicked item value
                String  itemValue    = (String) listView.getItemAtPosition(position);

                // Show Alert
                Toast.makeText(getApplicationContext(),
                        "Position :"+ position +"  ListItem : " +itemValue , Toast.LENGTH_LONG)
                        .show();
            }

        });

        //  sr.setCommand( "GetUsers" );
        //   sr.setUrl( getAllUsersUrl );
        //  sr.makeRequest( "GETUSERS" );
    }

    public void gotoPreferences( View v ) {
        if( loggedIn ) {
            startActivity( new Intent( this, PreferencesActivity.class ) );
        }
    }

    public void getAllUsersOnClick( View v ){
        sr.setUrl( getAllUsersUrl );
        sr.makeRequest( "GETALLUSERS" );
    }

    public void clickLogin( View v ) {
        if (!loggedIn) {
            sr.setUrl( loginUrl );
            password = edtPassword.getText().toString();
            username = edtUsername.getText().toString();
            sr.setUsername( username );
            sr.setPassword( password );
            sr.makeRequest( "LOGIN" );
        } else {
            //logout
            sr.setUrl( logoutUrl );
            sr.makeRequest( "LOGOUT" );
            loggedIn = false;
            userPreferences.setEnabled( false );
            startExistingGame.setEnabled( false );
            btnStartGame.setEnabled( false );
            loginButton.setText("Login");
        }
    }

    public void startGameClick( View v ) {
        sr.setUrl( startGameUrl );
        sr.makeRequest( "STARTGAME" );
    }

    public void startExistingGameClick( View v ) {
        gameId = Integer.valueOf( edtGameID.getText().toString() );
        startActivity( new Intent( this, Game.class ) );
    }

    public void processStartGame( String response ) {
        try {
            JSONObject jsonObject = new JSONObject( response );
            gameId = jsonObject.getInt( "game_id" );
            // Switch to Game view
            startActivity( new Intent( this, Game.class ) );
        } catch( JSONException e ) {
            e.printStackTrace();
        }
    }

    public void processLogin( String response ) {
        // Parse into an JSON Object
        try {
            JSONObject jsonObject = new JSONObject( response );
            user = new User();
            user.setId( jsonObject.getInt( "id" ) );
            user.setFirst_name( jsonObject.getString( "first_name" ) );
            user.setLast_name( jsonObject.getString( "last_name" ) );
            user.setOnline( jsonObject.getBoolean( "online" ) );
            user.setAvatar_image( jsonObject.getString( "avatar_image" ) );
            Log.i( TAG, user.toString() );
            loggedIn = true;
            userPreferences.setEnabled( true );
            startExistingGame.setEnabled( true );
            btnStartGame.setEnabled( true );
            loginButton.setText("Logout");
//            sr.getImage( imgAvatar, baseUrl + user.getAvatar_image() );
        } catch( JSONException e ) {
            e.printStackTrace();
        }
    }

    public void processLogout( String response ) {
        Toast.makeText(getApplicationContext(),
                response , Toast.LENGTH_SHORT)
                .show();
    }

    private void processGetAllUsers( String response ){
        ArrayList<String> userNames = new ArrayList<>();
        try {
            JSONArray usersArray = new JSONArray( response );
            for (int i = 0; i < usersArray.length(); i++) {
                JSONObject user = usersArray.getJSONObject(i);
                userNames.add(user.getString("avatar_name"));
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1, android.R.id.text1, userNames);
            listView.setAdapter(adapter);
        } catch( JSONException e ) {
            e.printStackTrace();
        }
    }

    @Override
    public void ProcessResponse( String command, String response ) {
        switch( command ) {
            case "LOGIN":
                Log.i( TAG, "LOGIN --- " + response );
                processLogin( response );
                break;

            case "LOGOUT":
                Log.i( TAG, "LOGOUT --- " + response );
                processLogout( response );
                break;


            case "GETALLUSERS":
                processGetAllUsers( response );
                Log.i( TAG, "GETALLUSERS --- " + response );
                break;

            case "GETUSERS":
                Log.i( TAG, "GETUSERS --- " + response );
                break;

            case "STARTGAME":
                Log.i( TAG, "STARTGAME --- " + response );
                processStartGame( response );
                break;

            case "GETSHIPS":
                Log.i( TAG, "GETSHIPS --- " + response );
                Game.processGetShips( getApplicationContext(), response );
                break;
            case "ADDSHIP":
                Log.i( TAG, "ADDSHIP --- " + response );
                Game.processAddShip( getApplicationContext(), response );
                break;
            case "GETSTATUS":
                Log.i( TAG, "GETSTATUS --- " + response );
                Game.processGetStatus( getApplicationContext(), response );
                break;
            case "ATTACK":
                Log.i( TAG, "ATTACK --- " + response );
                Game.processAttack( getApplicationContext(), response );
                break;

            default:
                break;
        }
    }

}
