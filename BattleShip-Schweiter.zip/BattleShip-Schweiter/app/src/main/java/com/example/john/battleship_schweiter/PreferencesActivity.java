package com.example.john.battleship_schweiter;

import android.os.Bundle;
import android.widget.EditText;

import com.android.volley.toolbox.NetworkImageView;

/**
 * Created by JohnS2774 on 5/30/2016.
 */
public class PreferencesActivity extends BaseActivity {

    EditText edtFirstName;
    EditText edtLastName;
    NetworkImageView imgAvatar;

    @Override
    protected void onCreate( Bundle savedInstanceState ) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.preferences );
        edtFirstName = (EditText) findViewById( R.id.edtFirstName );
        edtLastName = (EditText) findViewById( R.id.edtLastName );
        edtFirstName.setText( user.getFirst_name() );
        edtLastName.setText( user.getLast_name() );
        imgAvatar = (NetworkImageView) findViewById( R.id.imgAvatar );
        sr.setUrl( loginUrl );
        sr.getImage( imgAvatar, baseUrl + user.getAvatar_image() );
    }
}
