require 'test_helper'

class UserMailerTest < ActionMailer::TestCase
  test "submit_contact" do
    mail = UserMailer.submit_contact
    assert_equal "Submit contact", mail.subject
    assert_equal ["to@example.org"], mail.to
    assert_equal ["from@example.com"], mail.from
    assert_match "Hi", mail.body.encoded
  end

  test "publish_article" do
    mail = UserMailer.publish_article
    assert_equal "Publish article", mail.subject
    assert_equal ["to@example.org"], mail.to
    assert_equal ["from@example.com"], mail.from
    assert_match "Hi", mail.body.encoded
  end

end
