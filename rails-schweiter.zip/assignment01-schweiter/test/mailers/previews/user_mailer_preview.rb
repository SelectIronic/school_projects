# Preview all emails at http://localhost:3000/rails/mailers/user_mailer
class UserMailerPreview < ActionMailer::Preview

  # Preview this email at http://localhost:3000/rails/mailers/user_mailer/submit_contact
  def submit_contact
    UserMailer.submit_contact
  end

  # Preview this email at http://localhost:3000/rails/mailers/user_mailer/publish_article
  def publish_article
    UserMailer.publish_article
  end

end
