# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

include Faker

Product.destroy_all
Article.destroy_all
record_index = 0
100.times do
  n = (rand(0..99999) / 100.0)
  if record_index < Product.count
    Product.all[record_index].update(
        id: (record_index + 1),
        name: Commerce.product_name,
        description: Lorem.paragraph,
        quantity: rand(0..999),
        price: (n * (1 + rand.round(2))),
        cost: n,
        shipping_weight: rand(0..999),
        thumbnail: Avatar.image('my-own-slug', '50x50'),
        picture: Avatar.image('my-own-slug', '200x200')
    )
  else
    Product.create(
        name: Commerce.product_name,
        description: Lorem.paragraph,
        quantity: rand(0..999),
        price: (n * (1 + rand.round(2))),
        cost: n,
        shipping_weight: rand(0..999),
        thumbnail: Avatar.image('my-own-slug', '50x50'),
        picture: Avatar.image('my-own-slug', '200x200')
    )
  end

  author_first_name = Name.first_name
  author_last_name = Name.last_name
  date_published = Faker::Time.between(DateTime.now - 10, DateTime.now + 10).in_time_zone
  if date_published <= DateTime.now
    published_check = true
  else
    published_check = false
  end
  gravatar_id = Digest::MD5.hexdigest(Faker::Internet.safe_email("#{author_first_name}.#{author_last_name}").downcase)
  if record_index < Article.count
    Article.all[record_index].update(
        id: (record_index + 1),
        title: "#{Company.catch_phrase.capitalize}",
        author: "#{author_first_name} #{author_last_name}",
        published_date: date_published,
        published?: published_check,
        content: Lorem.paragraph,
        avatar_url: "http://gravatar.com/avatar/#{gravatar_id}.png?d=identicon"
    )
  else
    Article.create(
        title: "#{Company.catch_phrase.capitalize}",
        author: "#{author_first_name} #{author_last_name}",
        published_date: date_published,
        published?: published_check,
        content: Lorem.paragraph,
        avatar_url: "http://gravatar.com/avatar/#{gravatar_id}.png?d=identicon"
    )
  end
  record_index += 1
end

Product.all.each do |product|
  rand(0..10).times do
    product.reviews.create(
        author: Name.first_name,
        content: Lorem.sentence(10),
        rating: rand(1..10)
    )
  end
end