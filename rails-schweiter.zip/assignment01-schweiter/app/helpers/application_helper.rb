module ApplicationHelper

  def calendar(year, month)

    display_time = Time.new(year, month)

    next_year = year
    next_month = month + 1
    last_year = year
    last_month = month - 1
    if month + 1 > 12
      next_year = year + 1
      next_month = 1
    end
    if month - 1 < 1
      last_year = year - 1
      last_month = 12
    end

    first_day_of_month = display_time.strftime('%w').to_i
    days_in_month = Time.days_in_month(month, year)
    day_of_month = 1

    output = link_to('Previous Month', page_calendar_path(:year => last_year, :month => last_month))
    output += "<h2 id=\"calendar_h2\">#{display_time.strftime('%B ')} #{year}</h2>".html_safe
    output += link_to('Next Month', page_calendar_path(:year => next_year, :month => next_month))
    output += "<table id=\"calendar_table\">".html_safe
      output += '<tr>'.html_safe
        output += '<th>Sunday</th><th>Monday</th><th>Tuesday</th><th>Wednesday</th><th>Thursday</th><th>Friday</th><th>Saturday</th>'.html_safe
      output += '</tr>'.html_safe
      output += '<tr>'.html_safe
        first_day_of_month.times do
          output += '<td>&nbsp;</td>'.html_safe
        end
        days_in_month.times do
          if (day_of_month + first_day_of_month - 1) % 7 == 0 && (day_of_month + first_day_of_month - 1) != 0
            output += '</tr><tr>'.html_safe
          end
          output += "<td>#{day_of_month}</td>".html_safe
          day_of_month += 1
        end
        unless (first_day_of_month + days_in_month) % 7 == 0
        (7 - ((first_day_of_month + days_in_month) % 7)).times do
          output += '<td>&nbsp;</td>'.html_safe
        end
        end
      output += '</tr>'.html_safe
    output += '</table>'.html_safe

    output # I wanted to return output.html_safe but that wasn't working, so .html safe at the end of every HTML string
  end
end
