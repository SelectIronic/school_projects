class UserMailer < ActionMailer::Base
  default from: "from@example.com"

  # Subject can be set in your I18n file at config/locales/en.yml
  # with the following lookup:
  #
  #   en.user_mailer.submit_contact.subject
  #
  def submit_contact(form_data)
    @greeting = "Hi, here's a contact form submission."
    @form_data = form_data
    mail bcc: User.where('admin = ?', true).pluck(:email), subject: 'JohnS contact form'
  end

  # Subject can be set in your I18n file at config/locales/en.yml
  # with the following lookup:
  #
  #   en.user_mailer.contact_thanks.subject
  #
  def contact_thanks(email_address)
    @greeting = "Thank You for your feedback"
    mail to: email_address, subject: 'Thank you'
  end

  # Subject can be set in your I18n file at config/locales/en.yml
  # with the following lookup:
  #
  #   en.user_mailer.publish_article.subject
  #
  def publish_article(article, user_email)
    @greeting = "Hi, here's the latest article"
    @article = article
    mail to: user_email, subject: article.title
  end
end
