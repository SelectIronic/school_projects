class StoresController < ApplicationController

  # GET /stores
  # GET /stores.json
  def index
    table_page = params[:page].to_i
    @products = Product.page(table_page).per(10)
  end

  # GET /stores/1
  # GET /stores/1.json
  def show
    @product = Product.find(params[:id])
  end
end
