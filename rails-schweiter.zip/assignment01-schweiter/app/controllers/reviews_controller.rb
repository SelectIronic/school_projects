class ReviewsController < ApplicationController
  before_action :set_review, only: [:show, :edit, :update, :destroy]

  respond_to :html


  def create
    @product = Product.find(params[:product_id])
    @product.reviews.create(review_params)
    @product.save
    redirect_to store_show_path(@product.id)
  end

  def update
    @review.update(review_params)
  end

  def destroy
    @product = Product.find(params[:product_id])
    @review.destroy
    redirect_to store_show_path(@product.id)
  end

  private
    def set_review
      @review = Review.find(params[:id])
    end

    def review_params
      params.require(:review).permit(:author, :content, :rating, :product_id)
    end
end
