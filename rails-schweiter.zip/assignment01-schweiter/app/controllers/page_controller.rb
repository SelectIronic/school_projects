class PageController < ApplicationController

  def home

  end

  def about_us

  end

  def contact_us
    @full_name = params[:full_name]
    if @full_name == ''
      flash.now[:error] = 'Full Name may not be blank<br/>'.html_safe
    end
    @email_address = params[:email_address]
    if @email_address == ''
      flash.now[:error] = "#{flash.now[:error]}Email Address may not be blank<br/>".html_safe
    end
    @phone_number = params[:phone_number]
    @question = params[:question]
    @preferred_contact = params[:preferred_contact]
    @product = params[:product]
    @newsletter = params[:newsletter]
    @lies = params[:lies]
  end

  def mail_contact
    UserMailer.submit_contact(params).deliver
    UserMailer.contact_thanks(params[:email_address]).deliver
    redirect_to page_contact_us_path
  end

  def products
    @products ={
        :snow_skis => 200.00,
        :snow_board => 150.00,
        :snow_boots => 100.00,
        :mittens => 9.00,
        :gloves => 15.00,
        :hats => 20.00,
    }
  end

  def newsletter

  end

  def blog

  end

  def calendar
    @year = params[:year].to_i
    @month = params[:month].to_i
    unless params[:year] == '0' || @year > 0
      @year = Time.now.strftime('%Y').to_i
    end
    unless @month >= 1 && @month <= 12
      @month = Time.now.strftime('%m').to_i
    end
  end

  def articles

  end

  def login

  end

end