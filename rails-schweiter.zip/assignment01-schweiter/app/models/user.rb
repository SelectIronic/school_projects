class User < ActiveRecord::Base
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  # dave.jones@scc.spokane.edu
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable
end
