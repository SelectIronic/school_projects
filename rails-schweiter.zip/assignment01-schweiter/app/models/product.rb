class Product < ActiveRecord::Base
  has_many :reviews, dependent: :destroy
  validates :name, :description, :quantity, :price, :cost, :shipping_weight, :thumbnail, :picture, presence: true
  validates :name, length: { in: 2..64 }
  validates :description, length: { in: 8..256 }
  validates :quantity, numericality: { only_integer: true, greater_than_or_equal_to: 0 }
  validates :price, :cost, :shipping_weight, numericality: { greater_than_or_equal_to: 0 }
  validates :price, numericality: { greater_than_or_equal_to: :cost }
end
