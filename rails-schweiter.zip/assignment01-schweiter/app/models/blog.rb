class Blog < ActiveRecord::Base
  has_many :comments, dependent: :destroy
  validates :title, :author, :published_date, :content, presence: true
  validates :title, :author,  length: { in: 2..64 }
  validates :content, length: { in: 8..256 }
end
