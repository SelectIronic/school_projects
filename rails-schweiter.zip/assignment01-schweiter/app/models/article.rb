class Article < ActiveRecord::Base
  validates :title, :author, :published_date, :content, :avatar_url, presence: true
  #validates :title, :author, :published_date, :published?, :content, :avatar_url, presence: true
  validates :title, :author,  length: { in: 2..64 }
  validates :content, length: { in: 8..256 }

  after_save :send_newsletter

  # TODO: Ask Dave About published?_changed?
  # if self.published_changed?
  # => undefined method `published_changed?' for #<Article:0xb4ec598>
  # if self.published?_changed?
  # => undefined method `_changed?' for #<Article:0x6ae43c8>
  def send_newsletter
  if self.published?
      User.where('newsletter = ?', true).each do |user|
        UserMailer.publish_article(self, user.email).deliver
      end
    end
  end
end
